short answer questions (1st half)
coding questions (2nd half)
3/4 or 4/5 or whatever... depending on length
reference will be included:
* express api like
* some common js methods (arrays, strings, etc.)

WILL NOT INCLUDE:
* http specs
* explanation of concepts

in coding questions:
abbreviations where you can copy boilerplate code

if you write in "express setup"

const express... require


app.listen(...)



everything up to last class:
some database
* really simple (conceptual questions)
* OR nominal extra credit

topics
=====
* quickly review mongoose
* oo x net module, sockets (hw 3ish)
* 15 x call by sharing
* 14 x prototypes
* 13 x decorators
* 10 x middleware

store data
* database
	* relational
	* nosql / non-relational
		* document store
			* mongodb
				* everything is stored in documents
				* one doc is a bunch of key value pairs
				* ... oh, it's just a javascript object 
				* a collection holds a bunch of documents
				* can have multiple collections in a databse
				* a running instance of mongodb can have multiple databases
				* you can insert into a database collection that doesn't exist
				* not all attributes (keys) of documents have to be the same
				  within the collection
				* mongodb _doesn't_ care; it's pretty flexible
			* couchdb
		* key value store
		* object store
		* etc.
* in memory
* on file system
* "in cloud"

















































