function handleClick(evt) {
    const message = document.querySelector("#message").value;
    console.log('clicked', message);
    // get the value from the text input
    
    // post to api end point
    const req = new XMLHttpRequest();
    // configure the request
    req.open('POST', 'api/message');
    req.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8');
    req.addEventListener('load', function(evt) {
        console.log(req.status, req.responseText);
        if(req.status >= 200 && req.status < 300) {
            const msg = JSON.parse(req.responseText); 
            const div = document.body.appendChild(document.createElement('div'));
            div.textContent = msg.sent + ' ' + msg.text;
        }
    });

    // construct the body of our request
    // name=value
    // create body so that it fits expected format
    req.send('message=' + message);

}


let lastSentDate;


function getMessages() {
    const req = new XMLHttpRequest();
    let url = 'api/messages';
    if(lastSentDate) {
        url += '?lastSentDate=' + lastSentDate; 
    }

    req.open('GET', url);
    req.addEventListener('load', function(evt) {
        console.log(req.status, req.responseText);
        if(req.status >= 200 && req.status < 300) {
            const messages = JSON.parse(req.responseText); 
            for(const m of messages) {
                const div = document.body.appendChild(document.createElement('div'));
                div.textContent = m.sent + ' ' + m.text;
            }

            if(messages.length >= 1) {
                lastSentDate = messages[messages.length - 1].sent;
            }
        }
    });
    // setTimeout - delay call 
    // setInterval - repeat call with specific interval
    setTimeout(getMessages, 500);

    req.send();

}



function main() {
    getMessages();
    // TODO: retrieve messages and display
    // add event listener to button
    const btn = document.querySelector("#btn");
    btn.addEventListener('click', handleClick);
}



document.addEventListener("DOMContentLoaded", main);








